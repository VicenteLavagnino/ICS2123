# c)
import numpy as np


def solucion(m, lambda_, mu):
    matriz = []

    for i in range(m+2):
        fila_aux = []
        if i == 0:
            fila_aux.extend([-2.5*mu, lambda_])
            for j in range(m-1):
                fila_aux.extend([0])
            matriz.append(fila_aux)

        elif i == 1:
            fila_aux.extend([2.5*mu, -(2.5*mu + lambda_), lambda_])
            for j in range(m-2):
                fila_aux.extend([0])
            matriz.append(fila_aux)

        elif i == 2:
            fila_aux.extend([0, 2.5*mu, -(2.5*mu+lambda_), lambda_])
            for j in range(m-3):
                fila_aux.extend([0])
            matriz.append(fila_aux)

        elif i == 3:
            fila_aux.extend([0, 0, 2.5*mu, -(mu+lambda_), lambda_])
            for j in range(m-4):
                fila_aux.extend([0])
            matriz.append(fila_aux)

        elif i >= 4 and i < (m//2 - 1):
            for j in range(0, i-1):
                fila_aux.extend([0])
            fila_aux.extend([mu, -(mu+lambda_), lambda_])
            for j in range(i+2, m+1):
                fila_aux.extend([0])
            matriz.append(fila_aux)

        elif i == (m//2 - 1):
            for j in range(0, i-1):
                fila_aux.extend([0])
            fila_aux.extend([mu, -(mu+lambda_), 1.5*lambda_])
            for j in range(i+2, m+1):
                fila_aux.extend([0])
            matriz.append(fila_aux)

        elif i >= m//2 and i < m:
            for j in range(0, i-1):
                fila_aux.extend([0])
            fila_aux.extend([mu, -(mu+1.5*lambda_), 1.5*lambda_])
            for j in range(i+2, m+1):
                fila_aux.extend([0])
            matriz.append(fila_aux)

        elif i == m:
            for j in range(0, i-1):
                fila_aux.extend([0])
            fila_aux.extend([mu, -1.5*lambda_])
            matriz.append(fila_aux)

        elif i == m+1:
            for j in range(0, m+1):
                fila_aux.extend([1])
            matriz.append(fila_aux)

    matriz.remove(matriz[1])

    b = [0 for j in range(m)]
    b.extend([1])

    A = np.array(matriz)
    B = np.array(b)
    x = np.linalg.solve(A, B)

    return x


def sumar(x):
    p = 0
    for i in range(len(x)):
        if i >= ((len(x)-1)//2):
            p += x[i]

    return p


# e)
m = 30
lambda_ = 0.7
mu = 0.8
gamma = 0.2
rho = 0.5

# 62 nodos     hasta el 31 son (D,i) y desde el 32 parte (P,0) hasta el 62 : (P,30)
matriz = []
for i in range((m+1)*2+1):
    fila_aux = []
    if i >= 0 and i <= 30:
        if i == 0:
            fila_aux.extend([-(2.5*mu+gamma), lambda_])
            fila_aux.extend([0 for j in range(29)])
            fila_aux.extend([rho])  # nodo 32
            fila_aux.extend([0 for j in range(30)])
            matriz.append(fila_aux)

        elif i == 1:
            fila_aux.extend([2.5*mu, -(2.5*mu+lambda_+gamma), lambda_])
            fila_aux.extend([0 for j in range(29)])
            fila_aux.extend([rho])  # nodo 33
            fila_aux.extend([0 for j in range(29)])
            matriz.append(fila_aux)

        elif i == 2:
            fila_aux.extend([0, 2.5*mu, -(2.5*mu+lambda_+gamma), lambda_])
            fila_aux.extend([0 for j in range(29)])
            fila_aux.extend([rho])  # nodo 34
            fila_aux.extend([0 for j in range(28)])
            matriz.append(fila_aux)

        elif i == 3:
            fila_aux.extend([0, 0, 2.5*mu, -(mu+lambda_+gamma), lambda_])
            fila_aux.extend([0 for j in range(29)])
            fila_aux.extend([rho])  # nodo 35
            fila_aux.extend([0 for j in range(27)])
            matriz.append(fila_aux)

        elif i >= 4 and i < (m//2-1):
            for j in range(0, i-1):
                fila_aux.extend([0])

            fila_aux.extend([mu, -(mu+lambda_+gamma), lambda_])
            fila_aux.extend([0 for j in range(29)])
            fila_aux.extend([rho])  # nodo 29+i+2
            fila_aux.extend([0 for j in range(30-i)])
            matriz.append(fila_aux)

        elif i >= m//2 and i < m:
            for j in range(0, i-1):
                fila_aux.extend([0])

            fila_aux.extend([mu, -(mu+1.5*lambda_+gamma), 1.5*lambda_])
            fila_aux.extend([0 for j in range(29)])
            fila_aux.extend([rho])
            fila_aux.extend([0 for j in range(30-i)])
            matriz.append(fila_aux)

        elif i == m:
            for j in range(0, i-1):
                fila_aux.extend([0])

            fila_aux.extend([mu, -(1.5*lambda_+gamma)])
            fila_aux.extend([0 for j in range(i)])
            fila_aux.extend([rho])
            matriz.append(fila_aux)

    elif i > 30:
        if i == 31:  # (P,0)
            fila_aux.extend([0 for j in range(i - 31)])
            fila_aux.extend([gamma])
            fila_aux.extend([0 for j in range(61-i)])
            fila_aux.extend([-(rho+2.5*mu)])
            fila_aux.extend([0 for j in range(61-i)])
            matriz.append(fila_aux)

        elif i == 32:  # (P,1)
            fila_aux.extend([0 for j in range(i - 31)])
            fila_aux.extend([gamma])
            fila_aux.extend([0 for j in range(61-i)])
            fila_aux.extend([2.5*mu, -(rho+2.5*mu)])
            fila_aux.extend([0 for j in range(61-i)])
            matriz.append(fila_aux)

        elif i == 33:  # (P,2)
            fila_aux.extend([0 for j in range(i - 31)])
            fila_aux.extend([gamma])
            fila_aux.extend([0 for j in range(61-i)])
            fila_aux.extend([0, 2.5*mu, -(rho+2.5*mu)])
            fila_aux.extend([0 for j in range(61-i)])
            matriz.append(fila_aux)

        elif i == 34:  # (P,3)
            fila_aux.extend([0 for j in range(i - 31)])
            fila_aux.extend([gamma])
            fila_aux.extend([0 for j in range(61-i)])
            fila_aux.extend([0, 0, mu, -(rho+mu)])
            fila_aux.extend([0 for j in range(61-i)])
            matriz.append(fila_aux)

        elif i > 34 and i < 61:
            fila_aux.extend([0 for j in range(i - 31)])
            fila_aux.extend([gamma])
            fila_aux.extend([0 for j in range(61-i)])
            fila_aux.extend([0 for j in range(i-32)])
            fila_aux.extend([mu, -(rho+mu)])
            fila_aux.extend([0 for j in range(61-i)])
            matriz.append(fila_aux)

        elif i == 61:
            fila_aux.extend([0 for j in range(i - 31)])
            fila_aux.extend([gamma])
            fila_aux.extend([0 for j in range(i-32)])
            fila_aux.extend([mu, -(rho)])
            matriz.append(fila_aux)

        elif i == 62:
            for j in range(0, 62):
                fila_aux.extend([1])
            matriz.append(fila_aux)


b = [0 for j in range(61)]
b.extend([1])
A = np.array(matriz)
B = np.array(b)
x = np.linalg.solve(A, B)


def sumar_probabilidades(x):
    suma = 0
    for i in range(len(x)):
        if i >= 15 and i <= 30:
            suma += x[i]
    return suma


# i)
p = 0
for i in range(62):
    if i >= 31:
        p += x[i]
print(p)

# ii)
tasa = 0
for i in range(30):
    if i <= 2:
        tasa += (2.5*mu)*x[i]
    else:
        tasa += mu*x[i]
for i in range(30):
    if (i+31) <= 33:
        tasa += (2.5*mu)*x[i+31]
    else:
        tasa += (mu)*x[i+31]
print(tasa)

# iii)
tasa_2 = 0
for i in range(31):
    if i < 15:
        tasa_2 += lambda_*x[i]
    else:
        tasa_2 += 1.5*lambda_*x[i]
print(tasa_2)

# iv)
p_destruccion = 0
for i in range(31):
    p_destruccion += i*x[i]

for j in range(31):
    p_destruccion += j*x[j+31]
print(p_destruccion)

# v)

w = 1/(tasa_2-tasa)
print(w)
